<?php

namespace App\Providers;

use Filament\Http\Responses\Auth\Contracts\LoginResponse;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\ServiceProvider;
use Livewire\Livewire;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        URL::forceScheme('https');

        $this->app->bind(LoginResponse::class, \App\Filament\Pages\Auth\LoginResponse::class);

        Livewire::setUpdateRoute(function ($handle) {
            return Route::post('/php-wasm/cgi-bin/01J3YR5QM15578K6YRACP6X3RA/livewire/update', $handle);
        });
    }
}
