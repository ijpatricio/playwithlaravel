<?php

namespace App\Providers;

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\ServiceProvider;
use Livewire\Livewire;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        if ($this->app->environment() === 'production') {
            //
        }

        URL::forceScheme('https');

        Livewire::setUpdateRoute(function ($handle) {
            return Route::post('/php-wasm/cgi-bin/laravel-11/livewire/update', $handle);
        });
    }
}
