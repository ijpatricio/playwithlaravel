<div class="min-h-screen flex flex-col justify-center items-center space-x-4 gap-10">

    <div class="text-center">
        <h1 class="text-2xl font-bold">
            Livewire Counter
        </h1>

        <p class="text-gray-700">
            This is a simple Livewire component.
        </p>
    </div>


    <div class="flex gap-12 text-lg items-center">
        <?php echo e($counter); ?>


        <button wire:click="increment" wire:loading.attr="disabled"
                class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
        >
            Increment
        </button>
    </div>

    <div class="mt-16 text-lg">
        <a
            class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            href="01J3YR5QM15578K6YRACP6X3RA/admin"
        >
            Dashboard
        </a>
    </div>
</div>
<?php /**PATH /Users/joaopatricio/code/experiments/tall-wasm/resources/views/livewire/counter.blade.php ENDPATH**/ ?>